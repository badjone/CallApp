/**
 * 搜索设备界面
 */
Page({
  data: {
    logs: [],
    list:[],
    led:'123',
  },
   onLoad: function () {
    //console.log('onLoad')
    console.log("onLoad");
    //const ayx = "123";
     //console.log(ayx[0]);
    //console.log(ayxpath.length);
     //this.setData({ led: ayxpath})
//从服务器下载oad文件。
    //  wx.downloadFile({
    //    url: 'http://www.aiyuxun.cn/download/nrf52832_xxaa.bin',
    //    success(res)
    //    {
    //       if(res.statusCode == 200)
    //       {
    //         console.log(res.tempFilePath)
    //         console.log("down right")
    //         //wx.showToast({ title: '下载成功', icon: '', mask: true, duration: 1500 })
    //         //that.setData({ ayxpath: res.tempFilePath });
    //         var fs = wx.getFileSystemManager()
    //         fs.readFile(
    //         {
    //           filePath: res.tempFilePath,
    //           success(res2)
    //           {
    //             const hex = that.buf2hex(res2.data)
    //             console.log(hex)
    //           }
    //        })
           
    //       }
    //    }
    //  })
  //   
  //    //fs.writeFileSync(`${wx.env.USER_DATA_PATH}/hello.txt`, 'hello, world', 'utf8')
  //    fs.readFile(
  //      {
  //        filePath:'/oad/nrf52832_xxaa.bin',
  //        success(res)
  //       {
  //          console.log(res.size)
  //          console.log(res.digest)
  //       }
  //  })
    var that = this;
// const SDKVersion = wx.getSystemInfoSync().SDKVersion || '1.0.0'
// const [MAJOR, MINOR, PATCH] = SDKVersion.split('.').map(Number)
// console.log(SDKVersion);
// console.log(MAJOR);
// console.log(MINOR);
// console.log(PATCH);

// const canIUse = apiName => {
//   if (apiName === 'showModal.cancel') {
//     return MAJOR >= 1 && MINOR >= 1
//   }
//   return true
// }

// wx.showModal({
//   success: function(res) {
//     if (canIUse('showModal.cancel')) {
//       console.log(res.cancel)
//     }
//   }
// })
  // wx.closeBluetoothAdapter({
  //   success:function(res)
  //   {
  //     console.log("--closeBluetoothAdapter---success----------");
  //   },
  //   fail: function (res) {
  //     console.log("-----fail----------");
  //     // fail
  //     console.log(res);
  //   },
  //   complete: function (res) {
  //     // complete
  //     console.log("-----complete----------");
  //     console.log(res);
  //   }
  // })

  wx.openBluetoothAdapter({
      success: function(res){
        // success
        console.log("--openBluetoothAdapter---success----------");
        console.log(res);
      wx.startBluetoothDevicesDiscovery({
  services: [],
  success: function(res){
    // success
     console.log("-----startBluetoothDevicesDiscovery--success----------");
     console.log(res);
  },
  fail: function(res) {
    // fail
     console.log(res);
  },
  complete: function(res) {
    // complete
     console.log(res);
  }
})
},
fail: function(res) {
      //console.log("-----fail----------");
        // fail
         //console.log(res);
               },
      complete: function(res) {
        // complete
         //console.log("-----complete----------");
         //console.log(res);
      }
    })
     

  },
  onShow:function(){
 

  },
  bindViewTap1:function()
  {
    //url: '../logs/logs';
    
    var that = this;
    //const basic : "abc,def,ghi,";  
    //console.log(basic);
    wx.getBluetoothDevices({
      success: function (res) {
        // success
        //{devices: Array[11], errMsg: "getBluetoothDevices:ok"}
        console.log("getBluetoothDevices");
        console.log(res);
        that.setData({list: res.devices});
        console.log(that.data.list);
      },
      fail: function (res) {
        // fail
      },
      complete: function (res) {
        // complete
      }
    })
  },
   //点击事件处理
  bindViewTap: function(e) {
     console.log(e.currentTarget.dataset.title);
     console.log(e.currentTarget.dataset.name);
     console.log(e.currentTarget.dataset.advertisData);
     
    var title =  e.currentTarget.dataset.title;
    var name = e.currentTarget.dataset.name;
     wx.redirectTo({
       url: '../conn/conn?deviceId='+title+'&name='+name,
       success: function(res){
         // success
       },
       fail: function(res) {
         // fail
       },
       complete: function(res) {
         // complete
       }
     })
  },

   
  buf2hex: function (buffer) { // buffer is an ArrayBuffer
    return Array.prototype.map.call(new Uint8Array(buffer), x => ('00' + x.toString(16)).slice(-2)).join('');
  },
  ayxsendCode: function () {
    var that = this;
    var times = 0
    console.log("ayxsendCode");
    var i = setInterval(function () {
      if (times >= 17) {
        clearInterval(i)
      } else {
        console.log("count = " + times);
        //that.oadData(ayxOadData.substring(ayx_send_sel,times*244));
      }
      times++;
    }, 100)
  },

})
